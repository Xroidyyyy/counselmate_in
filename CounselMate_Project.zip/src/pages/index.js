
export default function Home() {
  return (
    <main className="text-white bg-black min-h-screen flex flex-col justify-center items-center">
      <h1 className="text-4xl font-bold">Welcome to CounselMate</h1>
      <p className="mt-4 text-lg">AI Counselling in every language, starting free.</p>
    </main>
  );
}
